"""Historical / residual recovery analyzers."""
