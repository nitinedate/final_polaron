"""Edge scanner agent tests."""
